function fval=NLDhopf(x)
global nROI we dt Tmax sig bfilt2 afilt2 TR C a omega nSUB Projection_phdata NumAssemblies_ph Wph;

nn=0;
Cnew=zeros(nROI,nROI);
for i=1:nROI
    for j=1:nROI
       if (C(i,j)>0 || j == nROI-i+1)
            nn=nn+1;
            Cnew(i,j)=x(nn);
        end
    end
end
dsig = sqrt(dt*sig);
wC = we*Cnew;

t_all=1;
sumC = repmat(sum(wC,2),1,2); % for sum Cij*xj
timeserietotal2=zeros(nSUB*Tmax,nROI);
for nsub=1:nSUB
    xs=zeros(Tmax,nROI);
    
    %number of iterations, 100 willk�hrlich, weil reicht in diesem Fall
    z = 0.1*ones(nROI,2);	% --> x = z(:,1), y = z(:,2)
    nn=0;
    
    % discard first 3000 time steps
    for t=0:dt:1000
        suma = wC*z - sumC.*z;	% sum(Cij*xi) - sum(Cij)*xj
        zz = z(:,end:-1:1);     % flipped z, because (x.*x + y.*y)
        z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(nROI,2);
    end
    
    % actual modeling (x=BOLD signal (Interpretation), y some other oscillation)
    for t=0:dt:((Tmax-1)*TR)
        suma = wC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
        zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
        z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(nROI,2);
        if abs(mod(t,TR))<0.01
            nn=nn+1;
            xs(nn,:)=z(:,1)';
        end
    end
    
    %%%%
    BOLD=xs';
    Tmax2=nn;
    Phase_BOLD=zeros(nROI,Tmax2);
    
    for seed=1:nROI
        BOLD(seed,:)=BOLD(seed,:)-mean(BOLD(seed,:));
        signal_filt_sim =filtfilt(bfilt2,afilt2,BOLD(seed,:));
        Phase_BOLD(seed,:) = angle(hilbert(signal_filt_sim));
    end
    
    for t=1:Tmax2
        iPH=zeros(nROI,nROI);
        for n=1:nROI
            for m=1:nROI
                iPH(n,m) = cos(Phase_BOLD(n,t)-Phase_BOLD(m,t));
            end
        end
        [V1,~] = eigs(iPH,1);
        timeserietotal2(t_all,:) = V1;
        t_all = t_all+1;
    end
end
timeserietotal = timeserietotal2';
Projection_phsim =  Wph * timeserietotal;

for ass=1:NumAssemblies_ph
    [hks pks ksdist(ass)]=kstest2(Projection_phdata(ass,:),Projection_phsim(ass,:));
end
fval=mean(ksdist);
