clear all;
global nROI we dt Tmax sig bfilt2 afilt2 TR C a omega nSUB Projection_phdata NumAssemblies_ph Wph;

%% Set paths & directories

% Shuffle random seed.  Necessary in array parallelization to avoid
% repeating same random seed across arrays.
rng('shuffle');

% Find general path (enclosing folder of current directory)
path{1} = strsplit(pwd, '/');
path{3,1} = strjoin(path{1}(1:end-2),'/');
path{4,1} = strjoin(path{1}, '/');
path{1,1} = strjoin(path{1}(1:end-3),'/');
path{2,1} = fullfile(path{1},'MATLAB');

% Set required subdirectories
path{5,1} = fullfile(path{3},'Data');
path{6,1} = fullfile(path{3},'Functions');
path{7,1} = fullfile(path{3},'Results','LEICA');
path{8,1} = fullfile(path{3},'Results','EC');

% Add relevant paths
addpath(path{6});


%% Load data

% Load data
load(fullfile(path{5}, 'sc90'));
load(fullfile(path{7}, 'LEICA90_PhaseAssemblies_CIC.mat'));

% Set parameters
we = 0.2;
sig = 0.02;

% Compute connectivity
C = sc90;
Cnew{1} = C/max(max(C))*we;
Cnew{2} = Cnew{1};


%% Reload paths

clear path;

% Find general path (enclosing folder of current directory)
path{1} = strsplit(pwd, '/');
path{3,1} = strjoin(path{1}(1:end-2),'/');
path{4,1} = strjoin(path{1}, '/');
path{1,1} = strjoin(path{1}(1:end-3),'/');
path{2,1} = fullfile(path{1},'MATLAB');

% Set required subdirectories
path{5,1} = fullfile(path{3},'Data');
path{6,1} = fullfile(path{3},'Functions');
path{7,1} = fullfile(path{3},'Results','LEICA');
path{8,1} = fullfile(path{3},'Results','EC');


%% Convert data to cell array

nROI = N.ROI;
Tmax = T.scan;
I = nan(sum(N.subjects),1);
tc_aal = cell(sum(N.subjects),1);

nsub1=1;
for c = 1:N.condition
	for nsub = 1:N.subjects(c)
		signaldata=(squeeze(TS{c}(:,:,nsub,1)));
		if mean(mean(signaldata)) ~= 0
			tc_aal{nsub1}=signaldata;
			I(nsub1) = c-1;
			nsub1 = nsub1+1;
		end
	end
end
nSUB = nsub1-1;
TR = T.TR;
clear c nsub nsub1


%% Generate Butterworth filter

delt = TR;						% sampling interval
k = 2;							% 2nd order butterworth filter
fnq = 1/(2*delt);
flp = 0.04;						% lowpass frequency of filter
fhi = 0.07;						% highpass
Wn=[flp/fnq fhi/fnq];			% butterworth bandpass non-dimensional frequency
[bfilt2,afilt2] = butter(k,Wn);	% construct the filter


%% 

timeserietotaldata=zeros(nSUB*Tmax, nROI);
Wph = W.concat;
NumAssemblies_ph = size(Wph,1);

for c = 1:N.condition
	
	% Compute intrisic frequency per ROI
	omega = findomega(squeeze(TS{c}), nROI, nSUB, Tmax, TR, afilt2, bfilt2);
	
	% Set indices
	t_all=1;
	d = find(I==c-1);
	for nsub = d(1):d(end)
		
		%%%%%%% Hilbert Phase %%%%%%%
		
		signaldata = squeeze(tc_aal{nsub});
		Phase_BOLD_data = zeros(nROI,Tmax);
		for seed = 1:nROI
			signaldata(seed,:) = signaldata(seed,:)-mean(signaldata(seed,:));
			signal_filt_data = filtfilt(bfilt2,afilt2,signaldata(seed,:));
			Phase_BOLD_data(seed,:) = angle(hilbert(signal_filt_data));
		end
		
		%%%%%%% dFC %%%%%%%
		
		iPH = zeros(Tmax,nROI,nROI);
		for t = 1:Tmax
			for nSUB = 1:nROI
				for p = 1:nROI
					iPH(t,nSUB,p) = cos(Phase_BOLD_data(nSUB,t)-Phase_BOLD_data(p,t));
				end
			end
			[V1,~] = eigs(squeeze(iPH(t,:,:)),1);
			timeserietotaldata(t_all,:) = V1;
			t_all = t_all+1;
		end
	end
	timeserietotaldata = timeserietotaldata';
	Projection_phdata =  Wph * timeserietotaldata(:,1:t_all-1);
	
	% what is this for?
	dt = 0.1*T.TR/2;
	sig = 0.02;
	dsig = sqrt(dt)*sig; % to avoid sqrt(dt) at each time step
	
	
	%%%%%%%%% HOPF MODEL %%%%%%%%%
	
	% Fill variable vector
	nvars = 0;
	for i = 1:nROI
		for j = 1:nROI
			if (C(i,j)>0 || j == N.ROI-i+1)
				nvars = nvars+1;
				xinit(nvars) = Cnew{c}(i,j);
			end
		end
	end
	
	% Set parameters
	dt = 0.1*TR/2;
	a = -0.0*ones(nROI,2);
	lb = zeros(1,nvars);
	ub = 0.2*ones(1,nvars);
	initpop = 0.02*randn(20,nvars)+repmat(xinit,20,1);
	options = optimoptions('particleswarm', 'InitialSwarmMatrix',initpop,'MaxTime',90000,'Display', 'iter');
	
	% Run Hopf optimization
	[x,fval] = particleswarm(@NLDhopf,nvars,lb,ub,options);
	disp(['Optimized Particle Swarm', num2str(fval)]);
	
	% Refill connectivity matrix
	nn = 0;
	Cnew{c} = zeros(nROI,nROI);
	for i = 1:nROI
		for j = 1:nROI
			if (C(i,j)>0 || j == N.ROI-i+1)
				nn = nn+1;
				Cnew{c}(i,j) = x(nn);
			end
		end
	end
end


% save generative.mat Cnew we;

