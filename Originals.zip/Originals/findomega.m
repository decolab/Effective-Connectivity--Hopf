function omega = findomega(signaldata, nROI, NSUB, Tmax, TR, afilt, bfilt)


%% Extract power spectra

% Preallocate subject power spectra
PowSpect = nan(floor(Tmax/2), nROI, NSUB);

% Extract subject power spectra
for nsub = 1:NSUB
	% clear PowSpect
	freq = (0:Tmax/2-1) / Tmax*TR;
	[~, minfreq]=min(abs(freq-0.04));
	[~, maxfreq]=min(abs(freq-0.07));
	% nfreqs=length(freq);
	
	for seed=1:nROI
		x = detrend(demean(signaldata(seed,:)));
		ts = zscore(filtfilt(bfilt,afilt,x));
		pw = abs(fft(ts));
		PowSpect(:, seed, nsub) = pw(1:floor(Tmax/2)).^2/(Tmax/TR);
	end
end

% Extract mean power per ROI
Power_Areas = mean(PowSpect,3);
for seed=1:nROI
	Power_Areas(:,seed) = gaussfilt(freq, Power_Areas(:,seed)', 0.01);
end

% Find frequencies of maximum power
[maxpowdata, index] = max(Power_Areas);
freq = freq(index);

clear PowSpect Power_Areas

%%%%%%%%%%%%%%%%%%

omega = repmat(2*pi*freq',1,2);
omega(:,1) = -omega(:,1);



