clear all;
global N we dt Tmax sig bfilt2 afilt2 TR C a omega NSUB Projection_phdata NumAssemblies_ph Wph;

load empiricalICprob_Schizos.mat;


%%
load GC_GenCog.mat;
C=GrC;
Cnew=C/max(max(C))*0.2;
%%

load metadata.mat;

Group1=ageMatchedCtlForSZ;
N=82;
Tmax=152;
Isubdiag = find(tril(ones(N),-1));

load ucla_time_series.mat;
nsub1=1;
for nsub=Group1
    signaldata=(squeeze(time_series(:,:,nsub,1)));
    if mean(mean(signaldata,2),1)~=0
        tc_aal{nsub1}=signaldata';
        nsub1=nsub1+1;
    end
end
NSUB=length(Group1);
TR=2.;  % Repetition Time (seconds)

delt = TR;            % sampling interval
k=2;                  % 2nd order butterworth filter
fnq=1/(2*delt);
flp = .04;           % lowpass frequency of filter
fhi = .07;           % highpass
Wn=[flp/fnq fhi/fnq]; % butterworth bandpass non-dimensional frequency
[bfilt2,afilt2]=butter(k,Wn);   % construct the filter

%%%%%%%%%%%%%%%%%%

timeserietotaldata=zeros(NSUB*Tmax,N);

t_all=1;
for nsub=1:NSUB
    signaldata=squeeze(tc_aal{nsub});
    Phase_BOLD_data=zeros(N,Tmax);
    for seed=1:N
        signaldata(seed,:)=signaldata(seed,:)-mean(signaldata(seed,:));
        signal_filt_data =filtfilt(bfilt2,afilt2,signaldata(seed,:));
        Phase_BOLD_data(seed,:) = angle(hilbert(signal_filt_data));
    end
    
    iPH=zeros(Tmax,N,N);
    for t=1:Tmax
        for n=1:N
            for p=1:N
                iPH(t,n,p)=cos(Phase_BOLD_data(n,t)-Phase_BOLD_data(p,t));
            end
        end
        [V1,~]=eigs(squeeze(iPH(t,:,:)),1);
        timeserietotaldata(t_all,:)=V1;
        t_all=t_all+1;
    end
end
timeserietotaldata=timeserietotaldata';
Projection_phdata =  Wph * timeserietotaldata;

%%%%%%%%%%%%%%%%%%

dt=0.1*TR/2;
a=-0.0*ones(N,2);

nvars=0;
for i=1:N
    for j=1:N
        if (C(i,j)>0 || j==N/2+i)
            nvars=nvars+1;
            xinit(nvars)=Cnew(i,j);
        end
    end
end
lb=zeros(1,nvars);
ub=0.2*ones(1,nvars);
initpop=0.02*randn(20,nvars)+repmat(xinit,20,1);
options = optimoptions('particleswarm', 'InitialSwarmMatrix',initpop,'MaxTime',90000,'Display', 'iter');
[x,fval] = particleswarm(@NLDhopf,nvars,lb,ub,options);
display('Optimized Particle Swarm');
fval
nn=0;
Cnew=zeros(N,N);
for i=1:N
    for j=1:N
        if (C(i,j)>0 || j == N-i+1)
            nn=nn+1;
            Cnew(i,j)=x(nn);
        end
    end
end


save generative.mat Cnew we;

