clear all;

load GC_GenCog.mat;
C=GrC;
C=C/max(max(C))*0.2;

load metadata.mat;

Group1=ageMatchedCtlForSZ;

load  empiricalICprob_Schizos.mat;

N=82;
Tmax=152;
Isubdiag = find(tril(ones(N),-1));

load ucla_time_series.mat;
nsub1=1;
for nsub=Group1
    signaldata=(squeeze(time_series(:,:,nsub,1)));
    if mean(mean(signaldata,2),1)~=0
        tc_aal{nsub1}=signaldata';
        nsub1=nsub1+1;
    end
end
NSUB=length(Group1);

%%%%%%%%%%%%%%%

TR=2.;  % Repetition Time (seconds)

delt = TR;            % sampling interval
k=2;                  % 2nd order butterworth filter
fnq=1/(2*delt);
flp = .04;           % lowpass frequency of filter
fhi = .07;           % highpass
Wn=[flp/fnq fhi/fnq]; % butterworth bandpass non-dimensional frequency
[bfilt2,afilt2]=butter(k,Wn);   % construct the filter

%%%%%%%%%%%%%%%%%%


for nsub=1:NSUB
    clear PowSpect;
    signaldata=squeeze(tc_aal{nsub});
    TT=Tmax;
    Ts = TT*TR;
    freq = (0:TT/2-1)/Ts;
    [aux minfreq]=min(abs(freq-0.04));
    [aux maxfreq]=min(abs(freq-0.07));
    nfreqs=length(freq);
    
    for seed=1:N
        x=detrend(demean(signaldata(seed,:)));
        ts =zscore(filtfilt(bfilt2,afilt2,x));
        pw = abs(fft(ts));
        PowSpect(:,seed,nsub) = pw(1:floor(TT/2)).^2/(TT/TR);
    end
end

Power_Areas=mean(PowSpect,3);
for seed=1:N
    Power_Areas(:,seed)=gaussfilt(freq,Power_Areas(:,seed)',0.01);
end

[maxpowdata,index]=max(Power_Areas);
f_diff = freq(index);

clear PowSpect  Power_Areas ;

%%%%%%%%%%%%%%%%%%

omega = repmat(2*pi*f_diff',1,2); omega(:,1) = -omega(:,1);


dt=0.1*TR/2;
sig=0.02;
dsig = sqrt(dt)*sig; % to avoid sqrt(dt) at each time step

%%%%%%%%%%%%
%% Optimize
%%

%%%%%%%%%%%%%%

a=-0.0*ones(N,2);
ITER=1:200;
    
timeserietotaldata=zeros(NSUB*Tmax,N);

t_all=1;
for nsub=1:NSUB
    signaldata=squeeze(tc_aal{nsub});
    Phase_BOLD_data=zeros(N,Tmax);
    for seed=1:N
        signaldata(seed,:)=signaldata(seed,:)-mean(signaldata(seed,:));
        signal_filt_data =filtfilt(bfilt2,afilt2,signaldata(seed,:));
        Phase_BOLD_data(seed,:) = angle(hilbert(signal_filt_data));
    end
    
    iPH=zeros(Tmax,N,N);
    for t=1:Tmax
        for n=1:N
            for p=1:N
                iPH(t,n,p)=cos(Phase_BOLD_data(n,t)-Phase_BOLD_data(p,t));
            end
        end
        [V1,~]=eigs(squeeze(iPH(t,:,:)),1);
        timeserietotaldata(t_all,:)=V1;
        t_all=t_all+1;
    end
    FCphasesemp2(nsub,:,:)=squeeze(mean(iPH));
end
timeserietotaldata=timeserietotaldata';
FCphasesemp=squeeze(mean(FCphasesemp2));
Projection_phdata =  Wph * timeserietotaldata;

iwe=1;
Cnew=C;
Tmax1=Tmax*NSUB;
WE=0:0.02:2;
for we=WE
    we
    for iter=ITER
        wC = we*Cnew;
        sumC = repmat(sum(wC,2),1,2); % for sum Cij*xj
        xs=zeros(Tmax1,N);
        %number of iterations, 100 willk�hrlich, weil reicht in diesem Fall
        z = 0.1*ones(N,2); % --> x = z(:,1), y = z(:,2)
        nn=0;
        % discard first 3000 time steps
        for t=0:dt:1000
            suma = wC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
            zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
            z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
        end
        % actual modeling (x=BOLD signal (Interpretation), y some other oscillation)
        for t=0:dt:((Tmax1-1)*TR)
            suma = wC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
            zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
            z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
            if abs(mod(t,TR))<0.01
                nn=nn+1;
                xs(nn,:)=z(:,1)';
            end
        end
        
        %%%%
        BOLD=xs';
        signal_filt=zeros(N,nn);
        Phase_BOLD=zeros(N,nn);
        
        for seed=1:N
            BOLD(seed,:)=BOLD(seed,:)-mean(BOLD(seed,:));
            signal_filt =filtfilt(bfilt2,afilt2,BOLD(seed,:));
            Phase_BOLD(seed,:) = angle(hilbert(signal_filt));
        end
        
        iFCsim=zeros(size(BOLD,2),N,N);
        for t=1:size(BOLD,2)
            for n=1:N
                for p=1:N
                    iFCsim(t,n,p)=cos(Phase_BOLD(n,t)-Phase_BOLD(p,t));
                end
            end
        end
        FCphases=squeeze(mean(iFCsim));
        
        for i=1:N
            for j=i+1:N
                if (C(i,j)>0 || j==N/2+i)
                    Cnew(i,j)=Cnew(i,j)+0.01*(FCphasesemp(i,j)-FCphases(i,j));
                    if Cnew(i,j)<0
                        Cnew(i,j)=0;
                    end
                    Cnew(j,i)=Cnew(i,j);
                end
            end
        end
        
        Cnew=Cnew/max(max(Cnew))*0.2;
        D = abs(FCphasesemp-FCphases).^2;
        MSE = sum(D(:))/numel(FCphases);
        if MSE<0.01
            break;
        end
    end
    Phaseserror(iwe)=MSE
    Ceff(iwe,:,:)=Cnew;
    
    %%% Final Simulation
    t_all=1;
    wC = we*Cnew;
    sumC = repmat(sum(wC,2),1,2); % for sum Cij*xj
    timeserietotal2=zeros(NSUB*Tmax,N);
    for nsub=1:NSUB
        xs=zeros(Tmax,N);
        %number of iterations, 100 willk�hrlich, weil reicht in diesem Fall
        z = 0.1*ones(N,2); % --> x = z(:,1), y = z(:,2)
        nn=0;
        % discard first 3000 time steps
        for t=0:dt:1000
            suma = wC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
            zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
            z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
        end
        % actual modeling (x=BOLD signal (Interpretation), y some other oscillation)
        for t=0:dt:((Tmax-1)*TR)
            suma = wC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
            zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
            z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
            if abs(mod(t,TR))<0.01
                nn=nn+1;
                xs(nn,:)=z(:,1)';
            end
        end
        
        %%%%
        BOLD=xs';
        Tmax2=nn;
        Phase_BOLD=zeros(N,Tmax2);
        
        for seed=1:N
            BOLD(seed,:)=BOLD(seed,:)-mean(BOLD(seed,:));
            signal_filt_sim =filtfilt(bfilt2,afilt2,BOLD(seed,:));
            Phase_BOLD(seed,:) = angle(hilbert(signal_filt_sim));
        end
        
        for t=1:Tmax2
            iPH=zeros(N,N);
            for n=1:N
                for m=1:N
                    iPH(n,m)=cos(Phase_BOLD(n,t)-Phase_BOLD(m,t));
                end
            end
            [V1,~]=eigs(iPH,1);
            timeserietotal2(t_all,:)=V1;
            t_all=t_all+1;
        end
    end
    timeserietotal=timeserietotal2';
    Projection_phsim =  Wph * timeserietotal;
    
    for ass=1:NumAssemblies_ph
        [hks pks ksdist(ass)]=kstest2(Projection_phdata(ass,:),Projection_phsim(ass,:));
    end
    
    KSfitt(iwe)=mean(ksdist)
    iwe=iwe+1;
    
end

save generative_phases.mat Ceff WE omega sig;



