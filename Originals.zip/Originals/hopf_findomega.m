clear all;


%% Load and format data

% Load data
load GC_GenCog.mat;

% Load connectivity data
C=GrC;
C=C/max(max(C))*0.2;

% Load metadata (information on data organization)
load metadata.mat;

% Select group of interest
Group1=ageMatchedCtlForSZ;

% Load data
load empiricalICprob_Schizos.mat;
load ucla_time_series.mat;

% Set data parameters
N=82;					% number of ROIs
Tmax=152;				% time points per scan
NSUB=length(Group1);	% number of subjects
Isubdiag = find(tril(ones(N),-1));

% Load subject data into independent cells
nsub1=1;
for nsub=Group1
	signaldata=(squeeze(time_series(:,:,nsub,1)));
	if mean(mean(signaldata,2),1)~=0
		tc_aal{nsub1}=signaldata';
		nsub1=nsub1+1;
	end
end

%% %%%%%%%%%%%%%

% Set machine's time to repetition
TR=2.0;  % Repetition Time (seconds)


%% Define narrowband filter

delt = TR;            % sampling interval
k=2;                  % 2nd order butterworth filter
fnq=1/(2*delt);
flp = .04;           % lowpass frequency of filter
fhi = .07;           % highpass
Wn=[flp/fnq fhi/fnq]; % butterworth bandpass non-dimensional frequency
[bfilt2,afilt2]=butter(k,Wn);   % construct the filter



%% Extract power spectra

% Preallocate subject power spectra
PowSpect = nan(floor(Tmax/2), N, NSUB);

% Extract subject power spectra
for nsub = 1:NSUB
	% clear PowSpect
	signaldata=squeeze(tc_aal{nsub});
	freq = (0:Tmax/2-1)/Tmax*TR;
	[~, minfreq]=min(abs(freq-0.04));
	[~, maxfreq]=min(abs(freq-0.07));
	% nfreqs=length(freq);
	
	for seed=1:N
		x=detrend(demean(signaldata(seed,:)));
		ts =zscore(filtfilt(bfilt2,afilt2,x));
		pw = abs(fft(ts));
		PowSpect(:, seed, nsub) = pw(1:floor(Tmax/2)).^2/(Tmax/TR);
	end
end

% Extract mean power per ROI
Power_Areas = mean(PowSpect,3);
for seed=1:N
	Power_Areas(:,seed) = gaussfilt(freq, Power_Areas(:,seed)', 0.01);
end

% Find frequencies of maximum power
[maxpowdata, index] = max(Power_Areas);
freq = freq(index);

clear PowSpect Power_Areas

%%%%%%%%%%%%%%%%%%

omega = repmat(2*pi*freq',1,2);
omega(:,1) = -omega(:,1);


dt=0.1*TR/2;
sig=0.02;
dsig = sqrt(dt)*sig; % to avoid sqrt(dt) at each time step



